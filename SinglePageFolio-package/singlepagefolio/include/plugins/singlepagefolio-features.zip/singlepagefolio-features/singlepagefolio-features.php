<?php
/**
 * Singlepagefolio theme main features.
 *
 * Please note that this is a plugin just for singlepagefolio theme.
 * The author of this library (Simone Icardi) is NOT responsible
 * for the support of other themes. 
 *
 * @package   singlepagefolio-features
 * @version   2.0
 *
 * @wordpress-plugin
 * Plugin Name: Singlepagefolio Features
 * Description: This plugin just sets the main features of the Singlepagefolio theme (custom post type, custom fields and custom taxonomy). 
 * The Wordpress best practice says that it is better a plugin for this kind of features.
 * Version:     2.0
 * Author:      Simone Icardi
 * Author URI:  http://simoneicardi.com/
 * Text Domain: singlepagefolio
 * Domain Path: /languages/
 * Copyright:   2016, Simone Icardi
 */


// Security Note: blocking direct access to your plugin PHP files (sorce:https://codex.wordpress.org/Writing_a_Plugin)
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

//ADD CUSTOM taxonomy PROJECT TAGS 
add_action( 'init', 'create_prj_tax' );

function create_prj_tax() {
	register_taxonomy(
		'project_tag',
		'projects',
		array(
			'label' => __( 'project Tags', 'singlepagefolio' ),
			'rewrite' => array( 'slug' => 'project_tag' ),
			'hierarchical' => false,
            'update_count_callback' => '_update_post_term_count',
            'show_ui'               => true,
		)
	);
}





/*CUSTOM POST TYPE*/
add_action( 'init', 'cptui_register_my_cpts' );
function cptui_register_my_cpts() {
	$labels = array(
		"name" => "Projects",
		"singular_name" => "project",
		"menu_name" => "Projects",
		"add_new" => "Add Projects",
		"add_new_item" => "Add new Project",
		"edit" => "Edit Projects",
		"edit_item" => "Edit Project",
		"new_item" => "New Projects",
		"view" => "View Projects",
		"view_item" => "View Project",
		"search_items" => "Search Projects",
		"not_found" => "No Projects Found",
		"not_found_in_trash" => "No Projects Found in trash",
		"parent" => "Parent Found",
		);

	$args = array(
		"labels" => $labels,
		"description" => "portfolio projects",
		"public" => true,
		"show_ui" => true,
		"has_archive" => false,
		"show_in_menu" => true,
		"exclude_from_search" => true,
		"capability_type" => "page",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "projects", "with_front" => true ),
		"query_var" => true,
		"menu_position" => 50,		
		"supports" => array( "title", "editor", "trackbacks", "thumbnail", "page-attributes" ),		
		"taxonomies" => array( "project_tag" )
	);
	register_post_type( "projects", $args );

	$labels = array(
		"name" => "Footer",
		"singular_name" => "Footer",
		"menu_name" => "Footer",
		"all_items" => "Footer",
		"edit" => "Edit",
		"edit_item" => "Edit",
		);

	$args = array(
		"labels" => $labels,
		"description" => "footer\'s elements",
		"public" => true,
		"show_ui" => true,
		"has_archive" => false,
		"show_in_menu" => true,
		"exclude_from_search" => true,
		"capability_type" => "page",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => false,
		"query_var" => true,
		"menu_position" => 5,		
		"supports" => array( "page-attributes" ),		
	);
	register_post_type( "footer", $args );

	$labels = array(
		"name" => "Modal",
		"singular_name" => "Modal",
		"menu_name" => "Modal",
		"all_items" => "Modal",
		);

	$args = array(
		"labels" => $labels,
		"description" => "Modal single apparence at the bottom of the page for cookies warnig of whatever you want to comunicate",
		"public" => true,
		"show_ui" => true,
		"has_archive" => false,
		"show_in_menu" => true,
		"exclude_from_search" => true,
		"capability_type" => "page",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => false,
		"query_var" => true,
		"menu_position" => 70,		
		"supports" => array( "title", "editor", "page-attributes" ),		
	);
	register_post_type( "modal", $args );

	$labels = array(
		"name" => "Lightbox",
		"singular_name" => "Lightbox",
		"menu_name" => "Lightbox",
		"all_items" => "Lightbox",
		);

	$args = array(
		"labels" => $labels,
		"description" => "Intro Lightbox. Useful to show wishes or whatever you want as intro to your portfolio.",
		"public" => true,
		"show_ui" => true,
		"has_archive" => false,
		"show_in_menu" => true,
		"exclude_from_search" => true,
		"capability_type" => "page",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => false,
		"query_var" => true,
		"menu_position" => 70,		
		"supports" => array( "title", "page-attributes" ),		
	);
	register_post_type( "lightbox", $args );

// End of cptui_register_my_cpts()
}






/*CUSTOM FIELDS GROUP*/
define( 'ACF_LITE', true );// To remove all visual interfaces from the ACF plugin

if(function_exists("register_field_group"))
{
	register_field_group(array (
		'id' => 'acf_project-custom-fields',
		'title' => 'project custom fields. Featured image must be 500x400 pixel, except main project 900x800 and project with order=1 900x400.[:]',
		'fields' => array (
			array (
				'key' => 'field_5693d751802d7',
				'label' => 'Featured image dimensions',
				'name' => '',
				'type' => 'message',
				'message' => 'NOTE: Featured image must be 500x400 pixels, except:
	- main project must be 900x800 pixels;
	- project just below the main one (with attributes->order=1) must be 900x400 pixels.',
			),
			array (
				'key' => 'field_51d44153a23ef',
				'label' => 'publication/online date',
				'name' => 'online_data',
				'type' => 'date_picker',
				'instructions' => 'insert the online/publication date',
				'date_format' => 'yymmdd',
				'display_format' => 'dd/mm/yy',
				'first_day' => 1,
			),
			array (
				'key' => 'field_51d43b898da0d',
				'label' => 'project external link',
				'name' => 'url_site',
				'type' => 'text',
				'instructions' => 'link here your project to an online external page. (or even a description post if you want)',
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'formatting' => 'html',
				'maxlength' => '',
			),
			array (
				'key' => 'field_51d43a6fd6520',
				'label' => 'main project',
				'name' => 'inslide',
				'type' => 'true_false',
				'instructions' => 'is this the mani project? (if yes check this!)',
				'message' => 'is this the mani project?',
				'default_value' => 0,
			),
			array (
				'key' => 'field_51d4301360961',
				'label' => 'img carousel 1',
				'name' => 'img_carousel_1',
				'type' => 'image',
				'instructions' => 'carousel first image.
	Must be 900x800 pixels',
				'save_format' => 'url',
				'preview_size' => 'thumbnail',
				'library' => 'all',
			),
			array (
				'key' => 'field_51d4315635cde',
				'label' => 'img carousel 2',
				'name' => 'img_carousel_2',
				'type' => 'image',
				'instructions' => 'carousel second image.
	Must be 900x800 pixels',
				'save_format' => 'url',
				'preview_size' => 'thumbnail',
				'library' => 'all',
			),
			array (
				'key' => 'field_51d43384149ba',
				'label' => 'img carousel 3',
				'name' => 'img_carousel_3',
				'type' => 'image',
				'instructions' => 'carousel third image.
	Must be 900x800 pixels',
				'save_format' => 'url',
				'preview_size' => 'thumbnail',
				'library' => 'all',
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'projects',
					'order_no' => 0,
					'group_no' => 0,
				),
			),
		),
		'options' => array (
			'position' => 'normal',
			'layout' => 'no_box',
			'hide_on_screen' => array (
				0 => 'discussion',
				1 => 'send-trackbacks',
			),
		),
		'menu_order' => 0,
	));
	register_field_group(array (
		'id' => 'acf_footer',
		'title' => 'footer',
		'fields' => array (
			array (
				'key' => 'field_568e9798a08df',
				'label' => 'Text (desktop version)',
				'name' => 'footex1',
				'type' => 'wysiwyg',
				'instructions' => 'Insert here the short text you want to see in the footer extended version.',
				'default_value' => '',
				'toolbar' => 'basic',
				'media_upload' => 'no',
			),
			array (
				'key' => 'field_568e98dba08e0',
				'label' => 'Text (mobile version)',
				'name' => 'footex2',
				'type' => 'wysiwyg',
				'instructions' => 'Insert here the short text you want to see in the footer mobile	version.',
				'default_value' => '',
				'toolbar' => 'basic',
				'media_upload' => 'no',
			),
			array (
				'key' => 'field_568e9da9166ec',
				'label' => 'Email',
				'name' => 'foot_email',
				'type' => 'email',
				'instructions' => 'Insert here your email to link on the footer email icon. 
	Let empty here if you don\'t want this icon on your footer.',
				'default_value' => '',
				'placeholder' => 'youremail@yourdomain.com',
				'prepend' => '',
				'append' => '',
			),
			array (
				'key' => 'field_568e9ee7166ed',
				'label' => 'Linkedin page',
				'name' => 'foot_linkedin_page',
				'type' => 'text',
				'instructions' => 'Insert here your linkedin profile url to link on the footer linkedin icon. 
	Let empty here if you don\'t want this icon on your footer.',
				'default_value' => '',
				'placeholder' => 'http://',
				'prepend' => '',
				'append' => '',
				'formatting' => 'none',
				'maxlength' => '',
			),
			array (
				'key' => 'field_568e9fa6166ee',
				'label' => 'Skype user',
				'name' => 'foot_skype_user',
				'type' => 'text',
				'instructions' => 'Insert here your skype username to link on the footer skype icon. 
	Let empty here if you don\'t want this icon on your footer.',
				'default_value' => '',
				'placeholder' => 'yourskypeusername',
				'prepend' => '',
				'append' => '',
				'formatting' => 'none',
				'maxlength' => '',
			),
			array (
				'key' => 'field_568ea002166ef',
				'label' => 'twitter page',
				'name' => 'foot_twitter_page',
				'type' => 'text',
				'instructions' => 'Insert here your twitter page url to link on the footer twitter icon. 
	Let empty here if you don\'t want this icon on your footer.',
				'default_value' => '',
				'placeholder' => 'https://',
				'prepend' => '',
				'append' => '',
				'formatting' => 'none',
				'maxlength' => '',
			),
			array (
				'key' => 'field_568ea075166f0',
				'label' => 'Facebook page',
				'name' => 'foot_facebook_page',
				'type' => 'text',
				'instructions' => 'Insert here your facebook page url to link on the footer facebook icon. 
	Let empty here if you don\'t want this icon on your footer.',
				'default_value' => '',
				'placeholder' => 'https://',
				'prepend' => '',
				'append' => '',
				'formatting' => 'none',
				'maxlength' => '',
			),
			array (
				'key' => 'field_568ea0b5166f1',
				'label' => 'Google plus page',
				'name' => 'foot_google_plus_page',
				'type' => 'text',
				'instructions' => 'Insert here your g+ page url to link on the footer g+ icon. 
	Let empty here if you don\'t want this icon on your footer.',
				'default_value' => '',
				'placeholder' => 'https://',
				'prepend' => '',
				'append' => '',
				'formatting' => 'none',
				'maxlength' => '',
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'footer',
					'order_no' => 0,
					'group_no' => 0,
				),
			),
		),
		'options' => array (
			'position' => 'acf_after_title',
			'layout' => 'no_box',
			'hide_on_screen' => array (
				0 => 'permalink',
				1 => 'the_content',
				2 => 'excerpt',
				3 => 'custom_fields',
				4 => 'discussion',
				5 => 'comments',
				6 => 'revisions',
				7 => 'slug',
				8 => 'author',
				9 => 'format',
				10 => 'featured_image',
				11 => 'categories',
				12 => 'tags',
				13 => 'send-trackbacks',
			),
		),
		'menu_order' => 0,
	));
	register_field_group(array (
		'id' => 'acf_lightbox-fields',
		'title' => 'Lightbox fields',
		'fields' => array (
			array (
				'key' => 'field_5690eaffe3422',
				'label' => 'Image desktop version',
				'name' => 'img_desk',
				'type' => 'image',
				'instructions' => 'The image to show in the lightbox desktop version. Must be 600x650 pixels.',
				'save_format' => 'url',
				'preview_size' => 'full',
				'library' => 'all',
			),
			array (
				'key' => 'field_5690dfa23a6fb',
				'label' => 'Image mobile version',
				'name' => 'img_mv',
				'type' => 'image',
				'instructions' => 'The image to show in the lightbox mobile version. Must be 260x373 pixels.',
				'required' => 1,
				'save_format' => 'url',
				'preview_size' => 'full',
				'library' => 'all',
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'lightbox',
					'order_no' => 0,
					'group_no' => 0,
				),
			),
		),
		'options' => array (
			'position' => 'acf_after_title',
			'layout' => 'no_box',
			'hide_on_screen' => array (
				0 => 'permalink',
				1 => 'the_content',
				2 => 'excerpt',
				3 => 'custom_fields',
				4 => 'discussion',
				5 => 'comments',
				6 => 'revisions',
				7 => 'slug',
				8 => 'author',
				9 => 'format',
				10 => 'featured_image',
				11 => 'categories',
				12 => 'tags',
				13 => 'send-trackbacks',
			),
		),
		'menu_order' => 0,
	));
	register_field_group(array (
		'id' => 'acf_projects-custom-flieds-admin-only',
		'title' => 'projects custom flieds [admin only]',
		'fields' => array (
			array (
				'key' => 'field_51d4250ba4539',
				'label' => 'label url',
				'name' => 'url_label',
				'type' => 'text',
				'instructions' => '[admin only] external link label',
				'default_value' => 'go to the web site',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'formatting' => 'html',
				'maxlength' => '',
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'projects',
					'order_no' => 0,
					'group_no' => 0,
				),
				array (
					'param' => 'user_type',
					'operator' => '==',
					'value' => 'administrator',
					'order_no' => 1,
					'group_no' => 0,
				),
			),
		),
		'options' => array (
			'position' => 'side',
			'layout' => 'no_box',
			'hide_on_screen' => array (
			),
		),
		'menu_order' => 0,
	));
}

//Admin Hide media oprion for project text
add_action('admin_head', 'hide_mediapj');

function hide_mediapj() {
echo '<style type="text/css"><!--
.post-type-projects #insert-media-button { display:none !important;}
--></style>';
}

//Admin hiding the system pages
    //Step 1 – Create a New Role
register_activation_hook( __FILE__, 'my_initial_setup' );
function my_initial_setup() {
    $admin = get_role( 'administrator' );
    $overlord_caps = $admin->capabilities;
    $overlord_caps[] = 'be_overlord';
    $role = add_role( 'overlord', 'Overlord', $overlord_caps );
}
    //Step 2 – Create a Custom Taxonomy for system pages
add_action( 'init', 'ny_page_category' );
function ny_page_category() {
	
	$show_ui = ( current_user_can( 'be_overlord' ) ) ? true : false;

	$labels = array(
		'name'              => 'Page Categories',
		'singular_name'     => 'Page Category',
		'search_items'      => 'Search Page Categories',
		'all_items'         => 'All Page Categories',
		'parent_item'       => 'Parent Page Category',
		'parent_item_colon' => 'Parent Page Category:',
		'edit_item'         => 'Edit Page Category',
		'update_item'       => 'Update Page Category',
		'add_new_item'      => 'Add New Page Category',
		'new_item_name'     => 'New Page Category Name',
		'menu_name'         => 'Page Categories',
	);
	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => $show_ui,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'page_category' ),
	);
	register_taxonomy( 'page_category', array( 'page' ), $args );
}
    //Step 3 – Modify the Admin Page Post List
add_action( 'pre_get_posts', 'my_hide_system_pages' );
function my_hide_system_pages( $query ) {
   if( is_admin() && !empty( $_GET['post_type'] ) && $_GET['post_type'] == 'page' && $query->query['post_type'] == 'page' && !current_user_can( 'be_overlord' ) ) {
       $query->set( 'tax_query', array(array(
           'taxonomy' => 'page_category',
           'field' => 'slug',
           'terms' => array( 'system-page' ),
           'operator' => 'NOT IN'
       )));
   }
}


?>