<?php if (!defined('W3TC')) die(); ?>
<?php $this->checkbox('minify.html.strip.crlf', false, 'html_') ?> <?php w3_e_config_label('minify.html.strip.crlf') ?></label><br />
