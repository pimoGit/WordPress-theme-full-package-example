<?php if (!defined('W3TC')) die(); ?>
<?php $this->checkbox('minify.htmltidy.options.clean', false, 'html_') ?> <?php w3_e_config_label('minify.htmltidy.options.clean') ?></label><br />
<?php $this->checkbox('minify.htmltidy.options.hide-comments', false, 'html_') ?> <?php w3_e_config_label('minify.htmltidy.options.hide-comments') ?></label><br />
